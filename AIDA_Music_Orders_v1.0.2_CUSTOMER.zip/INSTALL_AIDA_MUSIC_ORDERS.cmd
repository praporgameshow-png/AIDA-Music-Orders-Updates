@echo off
setlocal
set "TARGET=%LOCALAPPDATA%\Programs\AidaMusicOrders"
echo.
echo AIDA Music Orders - установка
 echo Папка: %TARGET%
echo.
if not exist "%TARGET%" mkdir "%TARGET%"
if not exist "%TARGET%\Integration" mkdir "%TARGET%\Integration"
if not exist "%TARGET%\Docs" mkdir "%TARGET%\Docs"

if not exist "%~dp0AIDA Music Orders.exe" (
  echo ОШИБКА: рядом с установщиком нет AIDA Music Orders.exe
  pause
  exit /b 1
)

copy /Y "%~dp0AIDA Music Orders.exe" "%TARGET%\AIDA Music Orders.exe" >nul
if exist "%~dp0AIDA Updater.exe" copy /Y "%~dp0AIDA Updater.exe" "%TARGET%\AIDA Updater.exe" >nul
if exist "%~dp0update_channel.json" copy /Y "%~dp0update_channel.json" "%TARGET%\update_channel.json" >nul
if exist "%~dp0Integration\*" xcopy /E /I /Y "%~dp0Integration" "%TARGET%\Integration" >nul
if exist "%~dp0Docs\*" xcopy /E /I /Y "%~dp0Docs" "%TARGET%\Docs" >nul

powershell -NoProfile -ExecutionPolicy Bypass -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\AIDA Music Orders.lnk');$s.TargetPath='%TARGET%\AIDA Music Orders.exe';$s.WorkingDirectory='%TARGET%';$s.Save()"

start "" "%TARGET%\AIDA Music Orders.exe"
echo Готово.
timeout /t 2 >nul
endlocal
