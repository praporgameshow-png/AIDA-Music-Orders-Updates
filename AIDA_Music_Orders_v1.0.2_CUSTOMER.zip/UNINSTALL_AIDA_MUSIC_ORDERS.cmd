@echo off
setlocal
set "TARGET=%LOCALAPPDATA%\Programs\AidaMusicOrders"
echo AIDA Music Orders - удаление программы
 echo Пользовательские данные в %%LOCALAPPDATA%%\AidaMusicOrders удаляться НЕ будут.
choice /M "Удалить файлы программы и ярлык"
if errorlevel 2 exit /b 0

del /Q "%USERPROFILE%\Desktop\AIDA Music Orders.lnk" 2>nul
rmdir /S /Q "%TARGET%" 2>nul
echo Готово. Настройки и история сохранены отдельно.
pause
endlocal
