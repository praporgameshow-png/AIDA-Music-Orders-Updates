AIDA MUSIC ORDERS — Streamer.bot + MiniChat
==========================================

1. В Streamer.bot используй действие AIDA MUSIC — Заказ из VK.
2. Первый Execute C# Code: вставь AIDA_MUSIC_1_API_AND_MESSAGE.cs.
3. Затем MiniChat Method Collection -> SendMessageReply.
4. Последний Execute C# Code: вставь AIDA_MUSIC_3_FINAL_RESULT.cs.
5. Триггер должен быть привязан к НОВОЙ награде VK Video Live, которая используется только AIDA.
6. Локальный API по умолчанию:
   http://127.0.0.1:18765/api/order

Важно:
- Streamer.bot и AIDA Music Orders должны быть запущены на одном ПК.
- Не запускай две копии AIDA одновременно: порт 18765 будет занят.
- Проверку можно выполнить в AIDA: Сервис -> Проверить подключение.
