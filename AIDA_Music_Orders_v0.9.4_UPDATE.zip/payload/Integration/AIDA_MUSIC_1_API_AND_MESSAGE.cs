using System;
using System.Net.Http;
using System.Text;
using Newtonsoft.Json;

public class CPHInline
{
    private static readonly HttpClient Http = new HttpClient
    {
        // AIDA v0.7.9 может ждать решения владельца по найденному неоригинальному варианту.
        // Пока окно подтверждения открыто, награда ещё не считается принятой.
        Timeout = TimeSpan.FromSeconds(300)
    };

    private sealed class ApiResponse
    {
        public bool ok { get; set; }
        public bool accepted { get; set; }
        public string error { get; set; }
        public string message { get; set; }
    }

    public bool Execute()
    {
        string userName = FirstNonEmpty(
            "userName",
            "user",
            "displayName",
            "minichat.Data.UserName"
        );

        string rewardText = FirstNonEmpty(
            "rawInput",
            "input",
            "text",
            "rewardInput",
            "userInput",
            "minichat.Data.Text",
            "minichat.Data.Message",
            "minichat.Data.Input",
            "minichat.Data.RewardInput",
            "minichat.Data.RawText",
            "minichat.Data.RawMessage"
        );

        if (string.IsNullOrWhiteSpace(userName))
            userName = "Неизвестный зритель";

        userName = userName.Trim();
        if (userName.Length > 80)
            userName = userName.Substring(0, 80);

        // По умолчанию награда считается отклонённой.
        // Этот код ВСЕГДА возвращает true, чтобы следующим шагом
        // Streamer.bot успел отправить сообщение в чат.
        bool accepted = false;
        string chatMessage;

        if (string.IsNullOrWhiteSpace(rewardText))
        {
            chatMessage =
                "↩️ @" + userName +
                ", в награде не найдена ссылка на YouTube, VK Video или Яндекс Музыку.";

            SetResult(accepted, chatMessage, "missing_link");
            return true;
        }

        rewardText = rewardText.Trim();

        try
        {
            var payload = new
            {
                nick = userName,
                message = rewardText,
                source = "VK Video Live — AIDA MUSIC"
            };

            string json = JsonConvert.SerializeObject(payload);

            using (var content = new StringContent(
                json,
                Encoding.UTF8,
                "application/json"
            ))
            {
                HttpResponseMessage response = Http.PostAsync(
                    "http://127.0.0.1:18765/api/order",
                    content
                ).GetAwaiter().GetResult();

                string responseBody = response.Content
                    .ReadAsStringAsync()
                    .GetAwaiter()
                    .GetResult();

                ApiResponse api = null;
                try
                {
                    api = JsonConvert.DeserializeObject<ApiResponse>(responseBody);
                }
                catch
                {
                    // Ниже будет использован понятный запасной текст.
                }

                accepted = response.IsSuccessStatusCode
                    && api != null
                    && (api.ok || api.accepted);

                if (accepted)
                {
                    chatMessage =
                        "🎵 @" + userName +
                        ", заказ принят и добавлен в очередь.";

                    SetResult(true, chatMessage, "");
                    CPH.LogInfo(
                        "AIDA MUSIC: заказ принят. Зритель: " + userName
                    );
                }
                else
                {
                    string reason = api != null
                        && !string.IsNullOrWhiteSpace(api.message)
                            ? api.message.Trim()
                            : "заказ не принят";

                    reason = TrimTrailingPeriod(reason);
                    chatMessage =
                        "↩️ @" + userName + ", " + reason + ".";

                    string errorCode = api != null
                        ? (api.error ?? "order_rejected")
                        : "order_rejected";

                    SetResult(false, chatMessage, errorCode);
                    CPH.LogWarn(
                        "AIDA MUSIC: заказ отклонён. HTTP "
                        + (int)response.StatusCode
                        + ". Ответ: "
                        + responseBody
                    );
                }
            }
        }
        catch (Exception ex)
        {
            chatMessage =
                "↩️ @" + userName +
                ", AIDA Music Orders не ответила. Заказ отклонён.";

            SetResult(false, chatMessage, "api_unavailable");
            CPH.LogError(
                "AIDA MUSIC: ошибка связи с программой. " + ex.Message
            );
        }

        // ВАЖНО: сообщение должно быть отправлено следующим Sub-Action.
        return true;
    }

    private void SetResult(bool accepted, string message, string errorCode)
    {
        CPH.SetArgument("message", message);
        CPH.SetArgument("aiAnswer", message);
        CPH.SetArgument("orderAccepted", accepted);
        CPH.SetArgument("accepted", accepted);
        CPH.SetArgument("success", accepted);
        CPH.SetArgument("orderError", errorCode ?? "");
    }

    private string FirstNonEmpty(params string[] argumentNames)
    {
        foreach (string name in argumentNames)
        {
            string value;
            if (CPH.TryGetArg(name, out value)
                && !string.IsNullOrWhiteSpace(value))
            {
                return value;
            }
        }

        return "";
    }

    private string TrimTrailingPeriod(string value)
    {
        return (value ?? "").Trim().TrimEnd('.', '!', '?', ' ');
    }
}
