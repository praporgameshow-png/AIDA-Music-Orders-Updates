using System;

public class CPHInline
{
    public bool Execute()
    {
        bool accepted;
        if (!CPH.TryGetArg("orderAccepted", out accepted))
        {
            CPH.LogError(
                "AIDA MUSIC: отсутствует orderAccepted. Награда отклонена для безопасности."
            );
            return false;
        }

        // true  — награда выполнена, баллы не возвращаются.
        // false — MiniChat считает обработку неуспешной и возвращает баллы.
        return accepted;
    }
}
